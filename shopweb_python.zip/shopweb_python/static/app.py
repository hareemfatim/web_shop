from flask import Flask,render_template,request

from flask_mysqldb import MySQL
import os
from werkzeug.utils import secure_filename


UPLOAD_FOLDER = '/path/to/the/uploads'
ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])



app=Flask(__name__)



app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'oic'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

mysql = MySQL(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/product',methods = ['GET','POST'])
def signup():
    


   
    if request.method == 'GET':
        return render_template('create.html')
    elif request.method == 'POST':
        Product_Name = request.form['Product_Name']
        Product_Price = request.form['Product_Price']
        Product_Qty = request.form['Product_Qty']
        Product_Des = request.form['Product_Des']
        Product_Image = request.files['Product_Image']
        
        cursor = mysql.connection.cursor()
        cursor.execute('''INSERT INTO `product` (`Product_Name`, `Product_Price`, `Product_Qty`, `Product_Des`,`Product_Image`) VALUES (%s,%s,%s,%s,%s)''',(Product_Name,Product_Price,Product_Qty, Product_Des,Product_Image))
        mysql.connection.commit()
        cursor.close()
        return 'Dear '+ Product_Name + ", you're product successfully inserted"

if __name__ == "__main__":
    app.run(debug=True)
    
